// BATAILLE — page de jeu
import { onAuthChange } from '../services/auth.js';
import { submitAnswer, finishGame } from '../services/game.js';

const DIFFICULTY_LABEL = { easy: '🟢 Facile', medium: '🟡 Moyen', hard: '🔴 Difficile' };

let state = null;
try {
  state = JSON.parse(sessionStorage.getItem('bataille_game'));
} catch (e) {
  state = null;
}

if (!state || !state.gameId || !Array.isArray(state.questions) || state.questions.length === 0) {
  window.location.href = '/theme-select.html';
}

onAuthChange((user) => {
  if (!user) window.location.href = '/auth.html';
});

const els = {
  progress: document.getElementById('progress'),
  difficultyTag: document.getElementById('difficulty-tag'),
  question: document.getElementById('question-text'),
  options: document.getElementById('options'),
  explanation: document.getElementById('explanation'),
  continueBtn: document.getElementById('btn-continue'),
  gameScreen: document.getElementById('game-screen'),
  endScreen: document.getElementById('end-screen'),
  endTitle: document.getElementById('end-title'),
  endScore: document.getElementById('end-score'),
  endPoints: document.getElementById('end-points'),
  endXp: document.getElementById('end-xp'),
  endStreak: document.getElementById('end-streak'),
  btnChallengeFriend: document.getElementById('btn-challenge-friend'),
};

let currentIndex = 0;
let questionStartedAt = Date.now();
let answering = false;

function renderQuestion() {
  const q = state.questions[currentIndex];
  els.progress.textContent = `Question ${currentIndex + 1} / ${state.questions.length}`;
  els.difficultyTag.textContent = DIFFICULTY_LABEL[q.difficulty] || '';
  els.question.textContent = q.question;
  els.explanation.textContent = '';
  els.explanation.classList.remove('is-visible');
  els.continueBtn.hidden = true;
  els.options.innerHTML = '';
  answering = false;
  questionStartedAt = Date.now();

  q.options.forEach((optionText, index) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'option-btn';
    btn.textContent = optionText;
    btn.addEventListener('click', () => handleAnswer(index));
    els.options.appendChild(btn);
  });
}

async function handleAnswer(selectedIndex) {
  if (answering) return;
  answering = true;
  const timeMs = Date.now() - questionStartedAt;
  const q = state.questions[currentIndex];
  const buttons = [...els.options.children];
  buttons.forEach((b) => { b.disabled = true; });

  try {
    const result = await submitAnswer(state.gameId, q.id, selectedIndex, timeMs);
    buttons[selectedIndex].classList.add(result.correct ? 'is-correct' : 'is-wrong');
    if (!result.correct) buttons[result.correctAnswer].classList.add('is-correct');
    els.explanation.textContent = result.explanation;
    els.explanation.classList.add('is-visible');
    els.continueBtn.hidden = false;
  } catch (error) {
    alert(error.message);
    buttons.forEach((b) => { b.disabled = false; });
    answering = false;
  }
}

async function endGame() {
  sessionStorage.removeItem('bataille_game');

  if (state.mode === 'challenge') {
    // Le résultat s'affiche sur l'écran de comparaison dédié, pas ici.
    try {
      await finishGame(state.gameId);
    } catch (error) {
      // On tente quand même d'aller à l'écran de bataille : s'il y a un
      // vrai problème, il s'affichera là-bas avec plus de contexte.
      console.error(error);
    }
    window.location.href = `/battle-result.html?code=${encodeURIComponent(state.code)}`;
    return;
  }

  els.gameScreen.hidden = true;
  els.endScreen.hidden = false;
  els.endTitle.textContent = '⏳ Calcul du score…';
  els.endScore.textContent = '';
  els.endPoints.textContent = '';

  try {
    const result = await finishGame(state.gameId);
    const won = result.correctCount >= Math.ceil(result.totalQuestions / 2);
    els.endTitle.textContent = won ? '🏆 BRAVO !' : '💪 Bien joué !';
    els.endScore.textContent = `${result.correctCount} / ${result.totalQuestions}`;
    els.endPoints.textContent = `${result.score} points`;
    els.endXp.textContent = `+${result.xpEarned} XP · Niveau ${result.level}`;
    els.endStreak.textContent = result.streakCount > 1
      ? `🔥 Série : ${result.streakCount} jours`
      : '🔥 Série : 1 jour';
  } catch (error) {
    els.endTitle.textContent = '⚠️ Erreur';
    els.endScore.textContent = error.message;
  }
}

els.btnChallengeFriend?.addEventListener('click', () => {
  window.location.href = '/challenge.html';
});

els.continueBtn.addEventListener('click', () => {
  currentIndex += 1;
  if (currentIndex >= state.questions.length) {
    endGame();
  } else {
    renderQuestion();
  }
});

if (state) renderQuestion();
